﻿Param(
  [string]$u,
  [string]$p,
  [string]$rg,
  [string]$vmName,
  [string]$loc
)
echo ("user:"+$u+ " | loc: " + $loc + " | pass: " +$p)
$azureAccountName =$u
$azurePassword = ConvertTo-SecureString $p -AsPlainText -Force

$psCred = New-Object System.Management.Automation.PSCredential($azureAccountName, $azurePassword)
Login-AzureRmAccount -Credential $psCred

Import-module  ".\Get-AzureRmVmPublicIP.ps1" -Force

start-sleep -s 180
while(1){
    $arrIp =  Get-AzureRmVmPublicIP -ResourceGroupName $rg -VMName $vmName
    $sb = {
             param
            (
                $rg,
                $Name,
                $psCred,
                $loc
            )
             Login-AzureRmAccount -Credential $psCred
             Set-AzureRmVMCustomScriptExtension -ResourceGroupName $rg `
                -VMName $Name `
                -Location $loc `
                -FileUri "https://raw.githubusercontent.com/nguyenvanvu/247Tool/master/test.ps1" `
                -Run "test.ps1" `
                -Name DemoScriptExtension
     }


    for ($i=0; $i -lt $arrIp.length; $i++) {
        $vm = Get-AzureRmVM -ResourceG $rg -Name $arrIp[$i].VMName -Status
       
        $Name = $arrIp[$i].VMName;
        #Get-AzureRmVMExtension -ResourceGroupName $rg -VMName $Name -Name DemoScriptExtension

	    if($vm.Statuses[0].Code.Equals("ProvisioningState/succeeded")){
            echo $Name +  "Extension"
           Start-Job -ScriptBlock $sb -ArgumentList $rg, $Name, $psCred, $loc
           if($Name.Equals("vps002")){
                start-sleep -s 20
                Exit

           }
        }else   {
            if($vm.Statuses[0].Code.Equals("ProvisioningState/updating") -eq $False){
                $i--;
             }
        }
        echo "sleep 10s"
        start-sleep -s 10
    }
     echo "sleep 5s"
     start-sleep -s 10

}